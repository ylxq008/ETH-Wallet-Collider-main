# ETH-Wallet-Collider
## Usage:
- Install [Node.js](https://nodejs.org/en/download/)
-  Running wallets and keys
-  npm install
- Command: node sc.js
- Run 10000
- Exists Generated wallet and key.txt

Lazy people
Generate. bat
Open to generate
Query. bat
Open to query


Check wallet balance
Command: node cx. js



### If you are lucky, you will see something like this:
(p.s. this one took about ~7 hours, there is no ETA, it depends on your luck and computing power)


If the wallet balance is greater than 0
Store in Wallet with Wallet with balance.txt



![Screenshot](https://snipboard.io/sGcveo.jpg)
## Disclaimer
- This software is provided as is, without any warranty. Use it at your own risk.
- This software is for educational purposes only. Do not use it to crack wallets of other people without their permission.
