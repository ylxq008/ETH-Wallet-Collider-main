async function getBalance(address) {
    const fetch = await import('node-fetch'); // 

    const rpcUrls = [
        'https://eth.llamarpc.com',
        'https://eth-mainnet.public.blastapi.io',
        'https://rpc.ankr.com/eth',
        'https://rpc.flashbots.net/', 
        'https://eth-mainnet.nodereal.io/v1/1659dfb40aa24bbb8153a677b98064d7', 
        'https://rpc.flashbots.net/', 
        'https://nodes.mewapi.io/rpc/eth', 
        'https://endpoints.omniatech.io/v1/eth/mainnet/publicrpc',
        'https://endpoints.omniatech.io/v1/eth/mainnet/f69d2862da704d50a37399346be6aded',
        // Add more nodes here
        // for example：'https://another-node.com/rpc'
        // 'https://yet-another-node.com/rpc'
    ];

    let rpcIndex = 0; // Set initial RPC node index
    const rpcUrl = rpcUrls[rpcIndex];
    const response = await fetch.default(rpcUrl, { // 
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            jsonrpc: '2.0',
            method: 'eth_getBalance',
            params: [address, 'latest'],
            id: 1
        })
    });

    const responseData = await response.json();
    if (responseData.error) {
        throw new Error(responseData.error.message);
    }

    const balanceWei = parseInt(responseData.result, 16);
    const balanceEth = balanceWei / 1e18;
    return balanceEth;
}

const rpcUrls = [
        'https://eth.llamarpc.com',
        'https://eth-mainnet.public.blastapi.io',
        'https://rpc.ankr.com/eth',
        'https://rpc.flashbots.net/', 
        'https://eth-mainnet.nodereal.io/v1/1659dfb40aa24bbb8153a677b98064d7', 
        'https://rpc.flashbots.net/', 
        'https://nodes.mewapi.io/rpc/eth', 
        'https://endpoints.omniatech.io/v1/eth/mainnet/publicrpc',
        'https://endpoints.omniatech.io/v1/eth/mainnet/f69d2862da704d50a37399346be6aded',
    // Add more nodes here
    // for example：'https://another-node.com/rpc'
    // 'https://yet-another-node.com/rpc'
];

module.exports = { getBalance, rpcUrls };
