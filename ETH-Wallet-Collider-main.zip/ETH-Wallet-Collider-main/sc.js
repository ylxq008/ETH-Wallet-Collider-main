const { ethers } = require('ethers');
const fs = require('fs');

// Generate random mnemonics
function generateRandomWallet() {
  const wallet = ethers.Wallet.createRandom();
  return { address: wallet.address, privateKey: wallet.privateKey };
}

// 
function main() {
  try {
    const numberOfWallets = 10000;
    for (let i = 0; i < numberOfWallets; i++) {
      const { address, privateKey } = generateRandomWallet();
      const data = `${address},${privateKey}\n`;
      fs.appendFileSync('Generated wallet and key.txt', data);
      console.log(`Generated Wallet ${i + 1}/${numberOfWallets}: Address ${address}`);
    }
    console.log(`Successfully generated ${numberOfWallets} wallet addresses and private keys.`);
  } catch (error) {
    console.error('An error occurred:', error);
  }
}

// 
main();
